package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfiniteClientApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(InfiniteClientApplication.class, args);
	}

}
