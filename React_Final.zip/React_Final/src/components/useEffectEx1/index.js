import useEffectEx1 from "./useEffectEx1"
export default useEffectEx1;
