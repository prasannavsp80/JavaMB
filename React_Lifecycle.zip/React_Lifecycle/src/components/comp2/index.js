import comp2 from "./comp2"
export default comp2;
