import comp4 from "./comp4"
export default comp4;
