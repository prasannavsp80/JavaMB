import comp3 from "./comp3"
export default comp3;
