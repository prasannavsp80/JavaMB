import comp1 from "./comp1"
export default comp1;
