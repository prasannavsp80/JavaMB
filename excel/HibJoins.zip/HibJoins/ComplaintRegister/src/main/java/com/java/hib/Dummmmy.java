package com.java.hib;

public class Dummmmy {

	public static void main(String[] args) {
		System.out.println(new ComplaintDAOImpl().generateComplaintId());
	}
}
