package com.java.jsp;

public class Hello {

	private String greeting = "Good Morning...";

	public String getGreeting() {
		return greeting;
	}

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}
}
