package com.example.demo;

public enum LeaveStatus {
	PENDING, APPROVED, REJECTED
}
