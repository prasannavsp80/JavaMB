package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbDemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(SbDemo2Application.class, args);
	}

}
