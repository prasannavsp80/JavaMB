package com.example.demo;

public enum OrderStatus {
	ACCEPTED, DENIED,PENDING
}
