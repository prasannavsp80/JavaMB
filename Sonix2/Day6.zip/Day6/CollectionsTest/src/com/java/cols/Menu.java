package com.java.cols;

public class Menu {

	private int menuId;
	private String itemName;
	private double price;
	private String rating;
	
}

// sort them by using itemName by default. 

