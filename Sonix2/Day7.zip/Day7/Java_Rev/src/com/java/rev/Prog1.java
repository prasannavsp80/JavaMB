package com.java.rev;

public class Prog1 {

	public static void main(String[] args) {
		Prog1 obj = new Prog1();
		System.out.println(obj.hashCode());
	}
}
