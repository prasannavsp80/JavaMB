package com.java.rev;

public class Test {
	int x;
	public static void main(String[] args) {
		System.out.println(new Test().x);
	}     	
}
