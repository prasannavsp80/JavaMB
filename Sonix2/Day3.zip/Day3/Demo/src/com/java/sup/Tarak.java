package com.java.sup;

public class Tarak extends Employ {

	public Tarak(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
