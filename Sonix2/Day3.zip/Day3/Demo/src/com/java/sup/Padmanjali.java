package com.java.sup;

public class Padmanjali extends Employ {

	public Padmanjali(int empno, String name, double basic) {
		super(empno, name, basic);
		// TODO Auto-generated constructor stub
	}

}
