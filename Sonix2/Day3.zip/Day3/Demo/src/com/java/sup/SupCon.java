package com.java.sup;

public class SupCon {
	public static void main(String[] args) {
		Employ e1 = new Padmanjali(1, "Padmanjali", 99234.22);
		Employ e2 = new Tarak(2, "Tarak", 88323.44);
		
		System.out.println(e1);
		System.out.println(e2);
	}
}
