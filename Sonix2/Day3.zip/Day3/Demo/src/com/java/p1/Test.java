package com.java.p1;

import com.java.inh.Demo;

public class Test {

	public void show() {
		Demo obj = new Demo();
		System.out.println(obj.publicName);
	}
}
