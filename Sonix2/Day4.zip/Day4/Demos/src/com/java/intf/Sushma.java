package com.java.intf;

public class Sushma implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Sushma...");
	}

	@Override
	public void email() {
		System.out.println("Email is sushma@gmail.com");
	}

	@Override
	public void mobile() {
		System.out.println("Mobile is 84828385");
	}

}
