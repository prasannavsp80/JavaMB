package com.java.intf;

public class Chandra implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Chandra Sekhar...");
	}

	@Override
	public void email() {
		System.out.println("Email is chandra@gmail.com");
	}

	@Override
	public void mobile() {
		System.out.println("Mobile is 88482355");
	}

}
