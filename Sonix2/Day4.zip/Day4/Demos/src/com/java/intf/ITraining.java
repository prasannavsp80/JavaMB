package com.java.intf;

public interface ITraining {
	String trainer = "Prasanna";
	String topic = "Java";
	String company = "SonixHr";
	void name();
	void email();
	void mobile();
}
