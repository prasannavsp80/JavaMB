package com.java.intf;

public class Mohammad implements ITraining {

	@Override
	public void name() {
		System.out.println("Name is Mohammad Shabir...");
	}

	@Override
	public void email() {
		System.out.println("Email is shabir@gmail.com");
	}

	@Override
	public void mobile() {
		System.out.println("Mohammad Mobiile is 94828385");
	}

}
