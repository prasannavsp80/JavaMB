package com.java.day1;

public class Quiz2 {

	public static void main(String[] args) {
		int a=3;
		int b = a++;
		int c = b++ - 2;
		System.out.println(c);
	}
}
