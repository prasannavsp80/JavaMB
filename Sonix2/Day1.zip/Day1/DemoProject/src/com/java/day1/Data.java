package com.java.day1;

public class Data {

	public void sayHello() {
		System.out.println("Good Morning to all...");
	}
	
	private void trainer() {
		System.out.println("Trainer is Prasanna...");
	}
	
	void company() {
		System.out.println("Company is SonixHr...");
	}
}
