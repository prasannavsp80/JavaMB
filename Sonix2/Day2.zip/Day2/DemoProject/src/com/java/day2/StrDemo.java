package com.java.day2;

public class StrDemo {

	public static void main(String[] args) {
		String s1="Chandra", s2="Ganesh", s3="Karthik", s4="Chandra";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
