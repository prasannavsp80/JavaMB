package com.java.hosp;

public interface HospitalDao {

	String addHospital(Hospital hospital);
}
