package com.java.customer;

public interface CustomerDao {

	String addCustomerDao(Customer customer);
}
