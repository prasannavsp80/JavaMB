package com.java.ex;

@FunctionalInterface
public interface ICalculation {
	int calc(int a, int b);
}
