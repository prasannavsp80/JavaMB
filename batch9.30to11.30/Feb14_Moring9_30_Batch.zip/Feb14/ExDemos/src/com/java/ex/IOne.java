package com.java.ex;

@FunctionalInterface
public interface IOne {

	void show();
}
