package com.java.cols;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapExample2 {

//	public static void main(String[] args) {
//		Map userData = new HashMap();
//		userData.put("Maneesh", "Maneesh123");
//		userData.put("Guru", "Vardhan");
//		userData.put("Shiva", "Shiva");
//		userData.put("Leela", "Chinmai");
//		userData.put("Sanghavi", "Sanghavi");
//		System.out.println("Map Data");
//		for (Set ent : userData.entrySet()) {
//			
//		}
//	}
}
