package com.java.gadjet;

public interface ProductsDao {

	String addProductDao(Products product);
}
