package com.java.jdk8;

public class OptionalExample {
	public static void main(String[] args) {
		String[] names = new String[10];
		if (names[5]==null) {
			System.out.println("Value is Not Present...");
		}
	}
}
