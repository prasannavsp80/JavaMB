package com.java.jdk8;

public interface IOne {
	default void show() {
		System.out.println("Show From Interface 1");
	}
}
