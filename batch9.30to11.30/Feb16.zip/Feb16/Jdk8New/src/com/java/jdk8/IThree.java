package com.java.jdk8;

public interface IThree {
	default void show() {
		System.out.println("Show from Interface 3");
	}
}
