package com.java.jdk8;

public interface ITwo {
	default void show() {
		System.out.println("Show From Interface 2");
	}
}
