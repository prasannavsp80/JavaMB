use sonixjdbc;

Insert into Employ(Empno, Name, Gender, Dept, Desig, Basic) 
values(1,'SubhraPrakash','MALE','Java','Programmer',88422),
(2,'Ganesh','MALE','Dotnet','Expert',77223),
(3,'Sonali','FEMALE','Java','Expert',77245),
(4,'Kaushik','MALE','Sql','Manager',77255),
(5,'Shivangi','FEMALE','Sql','Expert',77244),
(6,'Sourabh','MALE','Java','Programmer',77255),
(7,'SatyaPrakash','MALE','Sql','DBA',88422),
(8,'Tanya','FEMALE','Dotnet','Manager',87742);
