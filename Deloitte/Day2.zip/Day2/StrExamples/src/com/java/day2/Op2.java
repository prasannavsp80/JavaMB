package com.java.day2;

public class Op2 {

	public static void main(String[] args) {
		int x = 3;
		int y = ~x;
		System.out.println(y);
		
		x = 5;
		System.out.println(~x);
		
		x = -3;
		System.out.println(~x);
	}
}
