package com.java.day2;

public class Quiz8 {

	
	public static void main(String[] args) {
//		int ch='A';
//		  System.out.println(ch);
		
		 double b=38.6;
		   int y = (int)b;
		   System.out.println(y);
	}
}
 