package com.java.day2;

public class Quiz2 {

	public static void main(String[] args) {
		double y = 12.5;
		int x = (int)y;
		System.out.println(x);
	}
}
