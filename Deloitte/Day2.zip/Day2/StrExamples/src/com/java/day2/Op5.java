package com.java.day2;

public class Op5 {

	public static void main(String[] args) {
		int x = 80;
		
		System.out.println(x >> 4);
	}
}
