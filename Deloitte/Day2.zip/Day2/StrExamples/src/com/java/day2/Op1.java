package com.java.day2;

public class Op1 {

	public static void main(String[] args) {
		System.out.println(5^3);
		System.out.println(5^6);
	}
}
