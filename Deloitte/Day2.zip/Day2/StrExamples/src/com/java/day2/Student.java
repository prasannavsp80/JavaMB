package com.java.day2;

public class Student {

	int sid;
	String sname;
	String city;
	double cgp;
}
