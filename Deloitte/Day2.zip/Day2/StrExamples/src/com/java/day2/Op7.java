package com.java.day2;

public class Op7 {

	public static void main(String[] args) {
		System.out.println(7^5);
		int x=5;
		System.out.println(~x);
		/* ~x will be -6 as x is positive plesae move to next digit and add - to that*
		 * 
		 */
		 x=-5;
		 System.out.println(~x);
		/* ~x will be 4 as x is negaive please move to prev digit
		 * and remove - sign
		 */
	}
}
