package com.java.day2;

public class Quiz3 {

	
	public static void main(String[] args) {
		final String company = "Deloitte";
		System.out.println(company);
		// company = "Deloitte Ltd";
		/* Not Possible as final variables are not to be modified as used to declare constants */ 
	}
}
