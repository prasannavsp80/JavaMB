package com.java.day2;

public class Op4 {

	public static void main(String[] args) {
		int x = 50;
		   // 110010 as it moves to right
		
		System.out.println(x >> 2);
	}
}
