package com.java.day2;

public class Op6 {

	public static void main(String[] args) {
		int x = 40;
		System.out.println(x >> 3);
	}
}
