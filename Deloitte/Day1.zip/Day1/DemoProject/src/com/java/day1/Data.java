package com.java.day1;

public class Data {

	public void preeti() {
		System.out.println("Hi I am Preeti Desai...");
	}
	
	void sidhanth() {
		System.out.println("Hi I am Sidhanth Prakash...");
	}
	
	private void syed() {
		System.out.println("Hi I am Syed Majed Pasha...");
	}
}
