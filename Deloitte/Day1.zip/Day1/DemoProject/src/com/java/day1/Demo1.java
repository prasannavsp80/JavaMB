package com.java.day1;

/**
 * Program to demo about Increment/Decrement Opreators 
 * @author lenovo
 *
 */
public class Demo1 {

	public static void main(String[] args) {
		int i=10;
		int j = i++;
		System.out.println(i + " " +j);
	}
}
