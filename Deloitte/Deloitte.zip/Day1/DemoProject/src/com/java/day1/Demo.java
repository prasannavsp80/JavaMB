package com.java.day1;

public class Demo {

	public static void main(String[] args) {
		Data obj = new Data();
		obj.preeti();
		obj.sidhanth();
	}
}
