package com.java.day1;

public class ArgsDemo {
	public static void main(String[] args) {
		System.out.println("First Argument   " +args[0]);
		System.out.println("Second Argument  " +args[1]);
	}
}
